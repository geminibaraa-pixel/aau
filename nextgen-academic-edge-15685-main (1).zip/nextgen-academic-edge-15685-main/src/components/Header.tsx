import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Globe, Menu, X, LogIn, ChevronDown } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useNavigate } from 'react-router-dom';
import nguLogo from '@/assets/ngu-building.jpg';
import { mainNavRoutes, additionalRoutes } from '@/config/routes';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Separator } from '@/components/ui/separator';

export const Header = () => {
  const { language, toggleLanguage, t } = useLanguage();
  const navigate = useNavigate();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigation = (href: string, isRoute?: boolean) => {
    if (isRoute) {
      navigate(href);
      setIsMobileMenuOpen(false);
    } else {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
        setIsMobileMenuOpen(false);
      }
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled 
          ? 'bg-primary/95 backdrop-blur-md shadow-lg' 
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center gap-3 animate-fade-in">
            <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-secondary">
              <img src={nguLogo} alt="NGU Logo" className="w-full h-full object-cover" />
            </div>
            <div className="text-primary-foreground">
              <h1 className="text-xl font-display font-bold leading-tight">
                {t('جامعة الجيل الجديد', 'New Generation University')}
              </h1>
              <p className="text-xs text-secondary font-semibold">NGU</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6">
            {mainNavRoutes.map((item, index) => (
              <button
                key={index}
                onClick={() => handleNavigation(item.href, item.isRoute)}
                className="text-primary-foreground hover:text-secondary transition-colors duration-300 font-medium text-sm relative group"
              >
                {t(item.ar, item.en)}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-secondary transition-all duration-300 group-hover:w-full"></span>
              </button>
            ))}
            
            {additionalRoutes.length > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="text-primary-foreground hover:text-secondary transition-colors duration-300 font-medium text-sm relative group flex items-center gap-1">
                    {t('المزيد', 'More')}
                    <ChevronDown className="w-4 h-4" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align={language === 'ar' ? 'start' : 'end'} className="min-w-[200px]">
                  {additionalRoutes.map((item, index) => (
                    <DropdownMenuItem
                      key={index}
                      onClick={() => handleNavigation(item.href, item.isRoute)}
                      className="cursor-pointer"
                    >
                      {t(item.ar, item.en)}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </nav>

          {/* Login, Language Toggle & Mobile Menu */}
          <div className="flex items-center gap-4">
            <Button
              size="sm"
              onClick={() => navigate('/login')}
              className="bg-secondary text-primary hover:bg-secondary/90 font-semibold"
            >
              <LogIn className="w-4 h-4 ml-2" />
              {t('تسجيل الدخول', 'Login')}
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={toggleLanguage}
              className="bg-transparent border-secondary text-primary-foreground hover:bg-secondary hover:text-primary"
            >
              <Globe className="w-4 h-4 mr-2" />
              {language === 'ar' ? 'EN' : 'عربي'}
            </Button>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden text-primary-foreground hover:text-secondary transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetContent side={language === 'ar' ? 'right' : 'left'} className="w-80">
          <SheetHeader>
            <SheetTitle className="text-start font-display">
              {t('القائمة', 'Menu')}
            </SheetTitle>
          </SheetHeader>
          
          <div className="mt-6 space-y-6">
            <div>
              <h3 className="font-semibold mb-3 text-sm text-muted-foreground uppercase">
                {t('الصفحات الرئيسية', 'Main Pages')}
              </h3>
              <nav className="flex flex-col gap-2">
                {mainNavRoutes.map((item, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      handleNavigation(item.href, item.isRoute);
                      setIsMobileMenuOpen(false);
                    }}
                    className="text-lg font-medium text-foreground hover:text-secondary transition-colors text-start py-2 px-3 hover:bg-muted rounded-md"
                  >
                    {t(item.ar, item.en)}
                  </button>
                ))}
              </nav>
            </div>

            {additionalRoutes.length > 0 && (
              <>
                <Separator />
                <div>
                  <h3 className="font-semibold mb-3 text-sm text-muted-foreground uppercase">
                    {t('المزيد', 'More')}
                  </h3>
                  <nav className="flex flex-col gap-2">
                    {additionalRoutes.map((item, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          handleNavigation(item.href, item.isRoute);
                          setIsMobileMenuOpen(false);
                        }}
                        className="text-base font-medium text-foreground hover:text-secondary transition-colors text-start py-2 px-3 hover:bg-muted rounded-md"
                      >
                        {t(item.ar, item.en)}
                      </button>
                    ))}
                  </nav>
                </div>
              </>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </header>
  );
};
