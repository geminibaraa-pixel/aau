export interface NewsItem {
  id: string;
  slug: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  contentAr: string;
  contentEn: string;
  image?: string;
  date: string;
  views: number;
  tags?: string[];
}

export interface ProjectItem {
  id: string;
  slug: string;
  titleAr: string;
  titleEn: string;
  descAr: string;
  descEn: string;
  students: string[];
  progress?: number;
  year?: number;
  status: 'current' | 'completed';
  images?: string[];
  detailsAr?: string;
  detailsEn?: string;
  startDate?: string;
  endDate?: string;
}

export interface CenterItem {
  id: string;
  titleAr: string;
  titleEn: string;
  descAr: string;
  descEn: string;
  services: { ar: string; en: string }[];
  programs: { ar: string; en: string }[];
}

export interface PartnerItem {
  id: string;
  nameAr: string;
  nameEn: string;
  logo: string;
  type: 'local' | 'international';
  website?: string;
}

export interface OfferItem {
  id: string;
  titleAr: string;
  titleEn: string;
  descAr: string;
  descEn: string;
  image?: string;
  category: 'academic' | 'scholarship' | 'training' | 'other';
  validUntil?: string;
}

export interface FAQItem {
  id: string;
  questionAr: string;
  questionEn: string;
  answerAr: string;
  answerEn: string;
  category?: string;
}

export interface SearchResult {
  id: string;
  type: 'news' | 'project' | 'center' | 'offer';
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  link: string;
  image?: string;
}
