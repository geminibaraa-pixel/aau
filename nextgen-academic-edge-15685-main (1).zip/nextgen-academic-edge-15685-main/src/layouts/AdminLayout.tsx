import { Outlet, Link, useLocation } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { LayoutDashboard, Users, Newspaper, FolderKanban, HelpCircle, Settings, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { adminRoutes } from '@/config/routes';

export const AdminLayout = () => {
  const { t } = useLanguage();
  const location = useLocation();

  const menuItems = [
    { path: adminRoutes[0].href, icon: LayoutDashboard, label: t(adminRoutes[0].ar, adminRoutes[0].en) },
    { path: adminRoutes[1].href, icon: Users, label: t(adminRoutes[1].ar, adminRoutes[1].en) },
    { path: adminRoutes[2].href, icon: Newspaper, label: t(adminRoutes[2].ar, adminRoutes[2].en) },
    { path: adminRoutes[3].href, icon: FolderKanban, label: t(adminRoutes[3].ar, adminRoutes[3].en) },
    { path: adminRoutes[4].href, icon: HelpCircle, label: t(adminRoutes[4].ar, adminRoutes[4].en) },
    { path: adminRoutes[5].href, icon: Settings, label: t(adminRoutes[5].ar, adminRoutes[5].en) },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <aside className="w-64 bg-card border-r border-border">
        <div className="p-6">
          <h2 className="text-2xl font-bold text-secondary">
            {t('لوحة الإدارة', 'Admin Panel')}
          </h2>
        </div>
        <nav className="px-3 space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${
                  isActive(item.path)
                    ? 'bg-secondary text-secondary-foreground'
                    : 'hover:bg-muted'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
        <div className="absolute bottom-4 left-4 right-4">
          <Button variant="outline" className="w-full" asChild>
            <Link to="/login">
              <LogOut className="w-4 h-4 mr-2" />
              {t('تسجيل الخروج', 'Logout')}
            </Link>
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="container mx-auto p-6">
          <Outlet />
        </div>
      </main>
    </div>
  );
};
