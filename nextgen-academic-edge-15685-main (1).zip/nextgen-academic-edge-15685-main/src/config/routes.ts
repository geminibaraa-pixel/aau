export interface NavItem {
  ar: string;
  en: string;
  href: string;
  isRoute: boolean;
  showInMainNav?: boolean;
}

export const publicRoutes: NavItem[] = [
  { ar: 'الرئيسية', en: 'Home', href: '/', isRoute: true, showInMainNav: true },
  { ar: 'عن الجامعة', en: 'About', href: '/about', isRoute: true, showInMainNav: true },
  { ar: 'كلياتنا', en: 'Colleges', href: '/colleges', isRoute: true, showInMainNav: true },
  { ar: 'الأخبار', en: 'News', href: '/news', isRoute: true, showInMainNav: true },
  { ar: 'القبول', en: 'Admission', href: '/admission', isRoute: true, showInMainNav: true },
  { ar: 'المراكز', en: 'Centers', href: '/centers', isRoute: true, showInMainNav: false },
  { ar: 'الشركاء', en: 'Partners', href: '/partners', isRoute: true, showInMainNav: false },
  { ar: 'العروض', en: 'Offers', href: '/offers', isRoute: true, showInMainNav: false },
  { ar: 'الحياة الجامعية', en: 'Campus Life', href: '/campus-life', isRoute: true, showInMainNav: false },
  { ar: 'المشاريع', en: 'Projects', href: '/projects-studio', isRoute: true, showInMainNav: false },
  { ar: 'الأسئلة', en: 'FAQ', href: '/faq', isRoute: true, showInMainNav: false },
  { ar: 'تواصل معنا', en: 'Contact', href: '/contact', isRoute: true, showInMainNav: true },
];

export const mainNavRoutes = publicRoutes.filter(route => route.showInMainNav);
export const additionalRoutes = publicRoutes.filter(route => !route.showInMainNav && route.href !== '/');

export const adminRoutes = [
  { ar: 'لوحة التحكم', en: 'Dashboard', href: '/admin/dashboard' },
  { ar: 'المستخدمين', en: 'Users', href: '/admin/users' },
  { ar: 'الأخبار', en: 'News', href: '/admin/news' },
  { ar: 'المشاريع', en: 'Projects', href: '/admin/projects' },
  { ar: 'الأسئلة الشائعة', en: 'FAQ', href: '/admin/faq' },
  { ar: 'الإعدادات', en: 'Settings', href: '/admin/settings' },
];
