import { useParams, useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle } from 'lucide-react';

const centersData: Record<string, any> = {
  research: {
    titleAr: 'مركز البحوث والدراسات',
    titleEn: 'Research and Studies Center',
    descAr: 'مركز متخصص في البحث العلمي والدراسات الأكاديمية المتقدمة',
    descEn: 'Specialized center for scientific research and advanced academic studies',
    services: [
      { ar: 'إجراء البحوث العلمية', en: 'Conducting scientific research' },
      { ar: 'نشر الأبحاث في مجلات عالمية', en: 'Publishing research in international journals' },
      { ar: 'الإشراف على رسائل الماجستير والدكتوراه', en: 'Supervising master and PhD theses' },
    ],
    programs: [
      { ar: 'برنامج البحث المتقدم', en: 'Advanced Research Program' },
      { ar: 'برنامج النشر العلمي', en: 'Scientific Publishing Program' },
    ],
  },
  training: {
    titleAr: 'مركز التدريب والتطوير',
    titleEn: 'Training and Development Center',
    descAr: 'برامج تدريبية متنوعة لتطوير المهارات والقدرات',
    descEn: 'Diverse training programs for skills and capabilities development',
    services: [
      { ar: 'دورات تدريبية متخصصة', en: 'Specialized training courses' },
      { ar: 'ورش عمل عملية', en: 'Practical workshops' },
      { ar: 'شهادات معتمدة', en: 'Certified certificates' },
    ],
    programs: [
      { ar: 'برنامج تطوير المهارات', en: 'Skills Development Program' },
      { ar: 'برنامج القيادة', en: 'Leadership Program' },
    ],
  },
  consulting: {
    titleAr: 'مركز الاستشارات',
    titleEn: 'Consulting Center',
    descAr: 'خدمات استشارية متخصصة للمؤسسات والأفراد',
    descEn: 'Specialized consulting services for institutions and individuals',
    services: [
      { ar: 'استشارات إدارية', en: 'Management consulting' },
      { ar: 'استشارات تقنية', en: 'Technical consulting' },
      { ar: 'استشارات أكاديمية', en: 'Academic consulting' },
    ],
    programs: [
      { ar: 'برنامج الاستشارات المؤسسية', en: 'Institutional Consulting Program' },
      { ar: 'برنامج التطوير الاستراتيجي', en: 'Strategic Development Program' },
    ],
  },
};

export default function CenterDetails() {
  const { id } = useParams();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const center = centersData[id || 'research'];

  if (!center) return <div>Not Found</div>;

  return (
    <div className="min-h-screen py-16 bg-background">
      <div className="container mx-auto px-4">
        <Button variant="ghost" onClick={() => navigate('/centers')} className="mb-6">
          <ArrowRight className="w-4 h-4 mr-2" />
          {t('العودة للمراكز', 'Back to Centers')}
        </Button>

        <h1 className="text-4xl font-bold mb-4">{t(center.titleAr, center.titleEn)}</h1>
        <p className="text-muted-foreground text-lg mb-8">{t(center.descAr, center.descEn)}</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('الخدمات', 'Services')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {center.services.map((service: any, i: number) => (
                <div key={i} className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-secondary mt-0.5" />
                  <span>{t(service.ar, service.en)}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t('البرامج', 'Programs')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {center.programs.map((program: any, i: number) => (
                <div key={i} className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-secondary mt-0.5" />
                  <span>{t(program.ar, program.en)}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
