import { useParams, useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { ArrowRight, Calendar, Eye } from 'lucide-react';

const newsData: Record<string, any> = {
  '1': {
    titleAr: 'افتتاح مبنى الكلية الجديد',
    titleEn: 'Opening of New College Building',
    date: '2025-01-15',
    views: 245,
    contentAr: 'تم افتتاح مبنى الكلية الجديد بحضور كبار المسؤولين والطلاب...',
    contentEn: 'The new college building was opened in the presence of senior officials and students...',
  },
};

export default function NewsDetails() {
  const { id } = useParams();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const news = newsData[id || '1'];

  if (!news) return <div>Not Found</div>;

  return (
    <div className="min-h-screen py-16 bg-background">
      <div className="container mx-auto px-4 max-w-4xl">
        <Button variant="ghost" onClick={() => navigate(-1)} className="mb-6">
          <ArrowRight className="w-4 h-4 mr-2" />
          {t('العودة', 'Back')}
        </Button>

        <article>
          <h1 className="text-4xl font-bold mb-4">{t(news.titleAr, news.titleEn)}</h1>
          <div className="flex items-center gap-4 text-muted-foreground mb-8">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {news.date}
            </div>
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              {news.views}
            </div>
          </div>
          <div className="prose prose-lg max-w-none">
            <p>{t(news.contentAr, news.contentEn)}</p>
          </div>
        </article>
      </div>
    </div>
  );
}
