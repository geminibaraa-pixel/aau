import { useLanguage } from '@/contexts/LanguageContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Plus, Edit, Trash2 } from 'lucide-react';

const users = [
  { id: 1, name: 'أحمد محمد', role: 'admin', status: 'active', email: 'ahmed@example.com' },
  { id: 2, name: 'فاطمة علي', role: 'student', status: 'active', email: 'fatima@example.com' },
  { id: 3, name: 'محمد حسن', role: 'teacher', status: 'active', email: 'mohamed@example.com' },
  { id: 4, name: 'سارة أحمد', role: 'student', status: 'inactive', email: 'sara@example.com' },
  { id: 5, name: 'خالد يوسف', role: 'student', status: 'active', email: 'khaled@example.com' },
];

export default function Users() {
  const { t } = useLanguage();

  const getRoleLabel = (role: string) => {
    const roles: Record<string, { ar: string; en: string }> = {
      admin: { ar: 'مدير', en: 'Admin' },
      teacher: { ar: 'مدرس', en: 'Teacher' },
      student: { ar: 'طالب', en: 'Student' },
    };
    return t(roles[role].ar, roles[role].en);
  };

  const getStatusLabel = (status: string) => {
    return status === 'active'
      ? t('نشط', 'Active')
      : t('غير نشط', 'Inactive');
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">
            {t('إدارة المستخدمين', 'Users Management')}
          </h1>
          <p className="text-muted-foreground">
            {t('عرض وإدارة حسابات المستخدمين', 'View and manage user accounts')}
          </p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          {t('إضافة مستخدم', 'Add User')}
        </Button>
      </div>

      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t('الاسم', 'Name')}</TableHead>
              <TableHead>{t('البريد الإلكتروني', 'Email')}</TableHead>
              <TableHead>{t('الدور', 'Role')}</TableHead>
              <TableHead>{t('الحالة', 'Status')}</TableHead>
              <TableHead className="text-right">{t('الإجراءات', 'Actions')}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id}>
                <TableCell className="font-medium">{user.name}</TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>
                  <Badge variant="outline">{getRoleLabel(user.role)}</Badge>
                </TableCell>
                <TableCell>
                  <Badge variant={user.status === 'active' ? 'default' : 'secondary'}>
                    {getStatusLabel(user.status)}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="icon" className="mr-2">
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
