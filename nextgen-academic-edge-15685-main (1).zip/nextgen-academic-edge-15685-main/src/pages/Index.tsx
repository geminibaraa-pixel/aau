import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { HeroSection } from '@/components/HeroSection';
import { AboutSection } from '@/components/AboutSection';
import { CollegesSection } from '@/components/CollegesSection';
import { NewsSection } from '@/components/NewsSection';
import { ContactSection } from '@/components/ContactSection';
import { Footer } from '@/components/Footer';
import { Card } from '@/components/ui/card';

const Index = () => {
  const { t, language } = useLanguage();
  const ChevronIcon = language === 'ar' ? ArrowLeft : ArrowRight;

  const teamMembers = [
    'Albaraa Nashwan Naaman',
    'Osama Mohammed Al-Rujwai',
    'Riyadh Mohammed Al-Rouhani',
    'Emad Adel Al-Kawkabani',
    'Hamzah Mansour Al-Harazi',
  ];

  return (
    <div className="scroll-smooth">
      <main>
        <HeroSection />
        
        <AboutSection />
        <div className="container mx-auto px-4 -mt-8 mb-16 text-center">
          <Button asChild variant="outline" size="lg">
            <Link to="/about" className="gap-2">
              {t('اكتشف المزيد عن الجامعة', 'Discover More About Us')}
              <ChevronIcon className="w-4 h-4" />
            </Link>
          </Button>
        </div>

        <CollegesSection />
        <div className="container mx-auto px-4 -mt-8 mb-16 text-center">
          <Button asChild size="lg">
            <Link to="/colleges" className="gap-2">
              {t('استعرض جميع الكليات', 'View All Colleges')}
              <ChevronIcon className="w-4 h-4" />
            </Link>
          </Button>
        </div>

        <NewsSection />
        <div className="container mx-auto px-4 -mt-8 mb-16 text-center">
          <Button asChild size="lg">
            <Link to="/news" className="gap-2">
              {t('جميع الأخبار والفعاليات', 'All News & Events')}
              <ChevronIcon className="w-4 h-4" />
            </Link>
          </Button>
        </div>

        <ContactSection />
      </main>

      {/* Team Members Section */}
      <section className="py-16 bg-muted/30 border-t">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl font-display font-bold text-foreground mb-8">
              فريق العمل
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {teamMembers.map((member, index) => (
                <Card
                  key={index}
                  className="p-4 hover:shadow-lg hover:border-secondary transition-all duration-300"
                >
                  <p className="text-base font-semibold text-foreground">{member}</p>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
